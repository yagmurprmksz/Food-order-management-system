<?php

try{

    $db = new PDO("mysql:host=localhost; dbname=food-order; charset =utf8_general_ci", 'root', '');
    //echo "Veritabanı bağlantısı başarılı";
}
catch(Exception $e){
    echo $e->getMessage();

}


?>