<?php
ob_start();
session_start();

require 'login.php';

if(isset($_POST['register'])){
    //echo "Doğru yer";
    $username = $_POST['username'];
    $password = $_POST['password'];
    $password_again = $_POST['password_again'];

    if(!$username){
        echo "Please enter your username";

    }
    elseif(!$password || !$password_again){
        echo "Please enter your password";
    }
    elseif($password != $password_again){
        echo "The passwords you entered do not match";
    }
    else{
        //veritabanı kayıt işlemleri
        $sorgu = $db->prepare('INSERT INTO users SET user_name = ?, user_password = ?');
        $ekle = $sorgu->execute([
            $username, $password
        ]);
        if($ekle){
            echo "You registered successfully, you are being directed!";
            header('Refresh:2; ../index.php');
        }
        else{
            echo "Something went wrong";
        }
    }
}

if(isset($_POST['login'])){
    $username = $_POST['username'];
    $password = $_POST['password'];

    if(!$username){
        echo "Please Enter your username";
    }
    elseif (!$password) {
        echo "Please Enter your password";
    }
    else {
        $kullanici_sor = $db->prepare('SELECT * FROM users WHERE user_name = ? || user_password = ?');
        $kullanici_sor->execute([
            $username, $password

        ]);
        
        $say = $kullanici_sor->rowCount();
        if($say==1){
            $_SESSION['username']=$username;
            echo "You login successfully";
            header('Refresh:2; ../index.php');
        }
        else{
            echo "Something went wrong";
        }
    }

}

?>