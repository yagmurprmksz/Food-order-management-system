<?php

require 'login.php';

?>


<!DOCTYPE html>
<html>
<head>
    <title>LOGIN</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

        <div class="login">
            <div class="login-screen">
                <div class ="app-title">
                    <h1> REGISTER </h1>
                </div>
            <form action="process.php" method="post">
                <div class="login-form">
                    <div class="control-group">
                        <input type="text" name="username" class="login-field" placeholder= "Username" id="login-name">
                        <label class="login-field-icon fui-user" for="login-name"></label>
                    </div>
                    <div class="control-group">
                        <input type="password" name="password" class="login-field" placeholder="Password" id="login-pass">
                        <label class="login-field-icon fui-user" for="login-pass"></label>
                    </div>
                    <div class="control-group">
                        <input type="password" name="password_again" class="login-field" placeholder="Confirm Password" id="login-pass">
                        <label class="login-field-icon fui-user" for="login-pass"></label>
                    </div>
                </div>
                <button href="register.php" name="register" class="btn btn-primary btn-large btn-block">REGISTER</button>
        </form>  
        <a href="index.php"><button href="index.php" name="login" class="btn btn-primary btn-large btn-block">LOGIN</button></a>  
        </div>
    </div>
</body>



</html>